﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace Ejemplo_Simetrico
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }

        private void Cifrar_Click(object sender, EventArgs e)
        {
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] llave_hash;
            llave_hash = md5.ComputeHash(Encoding.UTF8.GetBytes(txtllave.Text));
            md5.Clear();

            byte[] textoBytes = UTF8Encoding.UTF8.GetBytes(txtOriginal.Text);
            TripleDESCryptoServiceProvider tripledes = new TripleDESCryptoServiceProvider();
            tripledes.Key = llave_hash;
            tripledes.Mode = CipherMode.ECB;
            tripledes.Padding = PaddingMode.PKCS7;

            ICryptoTransform encriptador = tripledes.CreateEncryptor();
            byte[] textoEncriptado = encriptador.TransformFinalBlock(textoBytes, 0, textoBytes.Length);
            tripledes.Clear();

            txtCifrado.Text = Convert.ToBase64String(textoEncriptado, 0, textoEncriptado.Length);

        }

        private void Desifrar_Click(object sender, EventArgs e)
        {
            try { 
            MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();
            byte[] llave_hash;
            llave_hash = md5.ComputeHash(Encoding.UTF8.GetBytes(txtllave.Text));
            md5.Clear();

            byte[] datos = Convert.FromBase64String(txtCifrado.Text);
            TripleDESCryptoServiceProvider tripledes = new TripleDESCryptoServiceProvider();
            tripledes.Key = llave_hash;
            tripledes.Mode = CipherMode.ECB;
            tripledes.Padding = PaddingMode.PKCS7;

            ICryptoTransform descriptor = tripledes.CreateDecryptor();
            byte[] resultado = descriptor.TransformFinalBlock(datos, 0, datos.Length);
            tripledes.Clear();

            txtOriginal.Text = UTF8Encoding.UTF8.GetString(resultado);
        }


        catch (Exception ex)
            {
                MessageBox.Show("Error al desencriptar" + ex.Message);
            }


}
}
    }
 
