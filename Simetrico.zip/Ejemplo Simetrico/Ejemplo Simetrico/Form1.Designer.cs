﻿
namespace Ejemplo_Simetrico
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCifrado = new System.Windows.Forms.TextBox();
            this.txtOriginal = new System.Windows.Forms.TextBox();
            this.txtllave = new System.Windows.Forms.TextBox();
            this.Desifrar = new System.Windows.Forms.Button();
            this.Cifrar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtCifrado
            // 
            this.txtCifrado.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtCifrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCifrado.Location = new System.Drawing.Point(309, 258);
            this.txtCifrado.Multiline = true;
            this.txtCifrado.Name = "txtCifrado";
            this.txtCifrado.Size = new System.Drawing.Size(328, 97);
            this.txtCifrado.TabIndex = 0;
            // 
            // txtOriginal
            // 
            this.txtOriginal.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtOriginal.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOriginal.Location = new System.Drawing.Point(309, 86);
            this.txtOriginal.Multiline = true;
            this.txtOriginal.Name = "txtOriginal";
            this.txtOriginal.Size = new System.Drawing.Size(328, 97);
            this.txtOriginal.TabIndex = 1;
            // 
            // txtllave
            // 
            this.txtllave.BackColor = System.Drawing.SystemColors.HighlightText;
            this.txtllave.Location = new System.Drawing.Point(818, 86);
            this.txtllave.Multiline = true;
            this.txtllave.Name = "txtllave";
            this.txtllave.Size = new System.Drawing.Size(200, 43);
            this.txtllave.TabIndex = 2;
            // 
            // Desifrar
            // 
            this.Desifrar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Desifrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Desifrar.Location = new System.Drawing.Point(427, 373);
            this.Desifrar.Name = "Desifrar";
            this.Desifrar.Size = new System.Drawing.Size(107, 33);
            this.Desifrar.TabIndex = 3;
            this.Desifrar.Text = "Desifrar";
            this.Desifrar.UseVisualStyleBackColor = false;
            this.Desifrar.Click += new System.EventHandler(this.Desifrar_Click);
            // 
            // Cifrar
            // 
            this.Cifrar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Cifrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Cifrar.Location = new System.Drawing.Point(427, 203);
            this.Cifrar.Name = "Cifrar";
            this.Cifrar.Size = new System.Drawing.Size(107, 31);
            this.Cifrar.TabIndex = 4;
            this.Cifrar.Text = "Cifrar";
            this.Cifrar.UseVisualStyleBackColor = false;
            this.Cifrar.Click += new System.EventHandler(this.Cifrar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(346, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 37);
            this.label1.TabIndex = 5;
            this.label1.Text = "Cifrado Simetrico";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(309, 86);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(328, 97);
            this.textBox2.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(309, 258);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(328, 97);
            this.textBox1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(875, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 37);
            this.label2.TabIndex = 6;
            this.label2.Text = "Llave";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1259, 660);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Cifrar);
            this.Controls.Add(this.Desifrar);
            this.Controls.Add(this.txtllave);
            this.Controls.Add(this.txtOriginal);
            this.Controls.Add(this.txtCifrado);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtCifrado;
        private System.Windows.Forms.TextBox txtOriginal;
        private System.Windows.Forms.TextBox txtllave;
        private System.Windows.Forms.Button Desifrar;
        private System.Windows.Forms.Button Cifrar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label2;
    }
}

