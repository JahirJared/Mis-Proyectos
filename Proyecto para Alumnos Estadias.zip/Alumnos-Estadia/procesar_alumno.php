<?php
require 'conexion.php';
require 'funciones.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $grupoId = $_POST['grupo_id'];
    $asesor = $_POST['asesor'];
    $fechaEntrega = $_POST['fecha_entrega'] ?: null;
    
    if (agregarAlumno($pdo, $nombre, $grupoId, $asesor, $fechaEntrega)) {
        header("Location: detalle_grupo.php?id=$grupoId&mensaje=Alumno agregado con éxito");
    } else {
        header("Location: detalle_grupo.php?id=$grupoId&mensaje=Error al agregar el alumno");
    }
    exit();
}
?>