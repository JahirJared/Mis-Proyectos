CREATE DATABASE gestion_alumnos;
USE gestion_alumnos;

CREATE TABLE grupos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL
);

CREATE TABLE alumnos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    grupo_id INT,
    estatus ENUM('pendiente', 'entregado') DEFAULT 'pendiente',
    fecha_entrega DATE,
	donacion VARCHAR(255),
    asesor VARCHAR(100),
    FOREIGN KEY (grupo_id) REFERENCES grupos(id)
);