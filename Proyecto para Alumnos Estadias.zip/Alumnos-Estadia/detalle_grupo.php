<?php
require 'conexion.php';
require 'funciones.php';

$grupo_id = $_GET['id'] ?? 0;
$grupo = obtenerGrupo($pdo, $grupo_id);
$alumnos = obtenerAlumnosPorGrupo($pdo, $grupo_id);

if (!$grupo) {
    die('Grupo no encontrado');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Grupo: <?= htmlspecialchars($grupo['nombre']) ?></title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Detalle del Grupo: <?= htmlspecialchars($grupo['nombre']) ?></h1>
    
    <h2>Agregar Nuevo Alumno</h2>
    <form action="procesar_alumno.php" method="post">
        <input type="hidden" name="grupo_id" value="<?= $grupo_id ?>">
        <input type="text" name="nombre" placeholder="Nombre" required>
        <input type="text" name="asesor" placeholder="Asesor" required>
        <input type="date" name="fecha_entrega" placeholder="Fecha de Entrega">
        <input type="submit" value="Agregar Alumno">
    </form>

    <h2>Importar Nombres de Alumnos desde CSV</h2>
<form action="importar_excel.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="grupo_id" value="<?= $grupo_id ?>">
    <input type="file" name="excel_file" accept=".csv" required>
    <input type="submit" value="Importar Nombres">
</form>
<p>Nota: El archivo CSV debe contener solo una columna con los nombres de los alumnos.</p>

<h2>Lista de Alumnos</h2>
<table>
    <tr>
        <th>Nombre</th>
        <th>Asesor</th>
        <th>Fecha de Entrega</th>
        <th>Donación</th>
        <th>Estatus</th>
        <th>Acciones</th>
    </tr>
    <?php foreach ($alumnos as $alumno): ?>
        <tr class="<?= htmlspecialchars($alumno['estatus']) ?>" data-alumno-id="<?= $alumno['id'] ?>">
            <td><?= htmlspecialchars($alumno['nombre']) ?></td>
            <td><?= htmlspecialchars($alumno['asesor']) ?></td>
            <td><?= $alumno['fecha_entrega'] ?? '-' ?></td>
            <td><?= htmlspecialchars($alumno['donacion'] ?? '-') ?></td>
            <td><?= htmlspecialchars($alumno['estatus']) ?></td>
            <td>
                <button onclick="editarAlumno(<?= $alumno['id'] ?>)">Editar</button>
                <button onclick="eliminarAlumno(<?= $alumno['id'] ?>)">Eliminar</button>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

    <a href="index.php">Volver a la lista de grupos</a>

    <script src="script.js"></script>
</body>
</html>