<?php
require 'conexion.php';
require 'funciones.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $asesor = $_POST['asesor'];
    $fechaEntrega = $_POST['fecha_entrega'] ?: null;
    $donacion = $_POST['donacion']; // Tratado como texto
    $estatus = $_POST['estatus'];

    if (editarAlumno($pdo, $id, $nombre, $asesor, $fechaEntrega, $donacion, $estatus)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>