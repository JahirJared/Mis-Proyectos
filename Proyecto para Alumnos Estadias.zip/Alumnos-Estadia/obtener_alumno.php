<?php
require 'conexion.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE id = ?");
    $stmt->execute([$id]);
    $alumno = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($alumno) {
        echo json_encode($alumno);
    } else {
        echo json_encode(['error' => 'Alumno no encontrado']);
    }
} else {
    echo json_encode(['error' => 'ID no proporcionado']);
}
?>