<?php
require 'conexion.php';
require 'funciones.php';

$grupos = obtenerGrupos($pdo);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Alumnos de Estadía</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Gestión de Alumnos de Estadía</h1>
    
    <h2>Crear Nuevo Grupo</h2>
    <form action="procesar_grupo.php" method="post">
        <input type="text" name="nombre_grupo" placeholder="Nombre del Grupo" required>
        <input type="submit" value="Crear Grupo">
    </form>

    <h2>Grupos</h2>
    <div id="grupos-container">
        <?php foreach ($grupos as $grupo): ?>
            <div class="grupo">
                <div class="grupo-header" onclick="toggleGrupo(<?= $grupo['id'] ?>)">
                    <?= htmlspecialchars($grupo['nombre']) ?>
                </div>
                <div id="grupo-content-<?= $grupo['id'] ?>" class="grupo-content">
                    <a href="detalle_grupo.php?id=<?= $grupo['id'] ?>">Ver detalles del grupo</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <script src="script.js"></script>
</body>
</html>