function toggleGrupo(grupoId) {
    var content = document.getElementById('grupo-content-' + grupoId);
    if (content.style.display === 'none' || content.style.display === '') {
        content.style.display = 'block';
    } else {
        content.style.display = 'none';
    }
}

function cambiarEstatus(alumnoId, nuevoEstatus) {
    fetch('cambiar_estatus.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'id=' + alumnoId + '&estatus=' + nuevoEstatus
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            let row = document.querySelector(`tr[data-alumno-id="${alumnoId}"]`);
            if (row) {
                // Remover todas las clases de estatus posibles
                row.classList.remove('Pendiente', 'Entregado', 'No-entregado');
                // Añadir la nueva clase de estatus
                row.classList.add(nuevoEstatus);
                // Actualizar el texto del estatus en la fila
                row.querySelector('td:nth-child(5)').textContent = nuevoEstatus;
            }
        } else {
            alert('Error al cambiar el estatus');
        }
    });
}

function editarAlumno(alumnoId) {
    fetch('obtener_alumno.php?id=' + alumnoId)
        .then(response => response.json())
        .then(alumno => {
            let modal = document.createElement('div');
            modal.className = 'modal';
            modal.style.display = 'block';
            modal.innerHTML = `
                <div class="modal-content">
                    <span class="close">&times;</span>
                    <h2>Editar Alumno</h2>
                    <form id="editar-alumno-form">
                        <input type="hidden" name="id" value="${alumno.id}">
                        <label for="nombre">Nombre:</label>
                        <input type="text" id="nombre" name="nombre" value="${alumno.nombre}" required>
                        <label for="asesor">Asesor:</label>
                        <input type="text" id="asesor" name="asesor" value="${alumno.asesor}" required>
                        <label for="fecha_entrega">Fecha de Entrega:</label>
                        <input type="date" id="fecha_entrega" name="fecha_entrega" value="${alumno.fecha_entrega || ''}">
                        <label for="donacion">Donación:</label>
                        <input type="text" id="donacion" name="donacion" value="${alumno.donacion || ''}">
                        <label for="estatus">Estatus:</label>
                        <select id="estatus" name="estatus">
                            <option value="Pendiente" ${alumno.estatus === 'Pendiente' ? 'selected' : ''}>Pendiente</option>
                            <option value="Entregado" ${alumno.estatus === 'Entregado' ? 'selected' : ''}>Entregado</option>
                            <option value="No entregado" ${alumno.estatus === 'No entregado' ? 'selected' : ''}>No entregado</option>
                        </select>
                        <button type="submit">Guardar Cambios</button>
                    </form>
                </div>
            `;

            document.body.appendChild(modal);

            let span = modal.querySelector('.close');
            span.onclick = function() {
                document.body.removeChild(modal);
            }

            let form = modal.querySelector('#editar-alumno-form');
            form.onsubmit = function(e) {
                e.preventDefault();
                let formData = new FormData(form);
                
                fetch('actualizar_alumno.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Alumno actualizado con éxito');
                        document.body.removeChild(modal);
                        location.reload();
                    } else {
                        alert('Error al actualizar el alumno');
                    }
                });
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los datos del alumno');
        });
}

function eliminarAlumno(alumnoId) {
    if (confirm('¿Estás seguro de que quieres eliminar este alumno?')) {
        fetch('eliminar_alumno.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'id=' + alumnoId
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Alumno eliminado con éxito');
                location.reload();
            } else {
                alert('Error al eliminar el alumno');
            }
        });
    }
}