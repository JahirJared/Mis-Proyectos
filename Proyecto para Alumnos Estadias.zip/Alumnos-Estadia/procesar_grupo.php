<?php
require 'conexion.php';
require 'funciones.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombreGrupo = $_POST['nombre_grupo'];
    
    if (crearGrupo($pdo, $nombreGrupo)) {
        header("Location: index.php?mensaje=Grupo creado con éxito");
    } else {
        header("Location: index.php?mensaje=Error al crear el grupo");
    }
    exit();
}
?>