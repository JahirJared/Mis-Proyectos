<?php
function obtenerGrupos($pdo) {
    $stmt = $pdo->query("SELECT * FROM grupos ORDER BY nombre");
    return $stmt->fetchAll();
}

function obtenerGrupo($pdo, $id) {
    $stmt = $pdo->prepare("SELECT * FROM grupos WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function obtenerAlumnosPorGrupo($pdo, $grupoId) {
    $stmt = $pdo->prepare("SELECT * FROM alumnos WHERE grupo_id = ? ORDER BY nombre");
    $stmt->execute([$grupoId]);
    return $stmt->fetchAll();
}

function crearGrupo($pdo, $nombreGrupo) {
    $stmt = $pdo->prepare("INSERT INTO grupos (nombre) VALUES (?)");
    return $stmt->execute([$nombreGrupo]);
}

function agregarAlumno($pdo, $nombre, $grupoId, $asesor, $fechaEntrega, $donacion = '') {
    $stmt = $pdo->prepare("INSERT INTO alumnos (nombre, grupo_id, asesor, fecha_entrega, donacion, estatus) VALUES (?, ?, ?, ?, ?, 'Pendiente')");
    return $stmt->execute([$nombre, $grupoId, $asesor, $fechaEntrega, $donacion]);
}

function cambiarEstatus($pdo, $id, $nuevoEstatus) {
    $stmt = $pdo->prepare("UPDATE alumnos SET estatus = ? WHERE id = ?");
    return $stmt->execute([$nuevoEstatus, $id]);
}

function editarAlumno($pdo, $id, $nombre, $asesor, $fechaEntrega, $donacion, $estatus) {
    $stmt = $pdo->prepare("UPDATE alumnos SET nombre = ?, asesor = ?, fecha_entrega = ?, donacion = ?, estatus = ? WHERE id = ?");
    return $stmt->execute([$nombre, $asesor, $fechaEntrega, $donacion, $estatus, $id]);
}

function eliminarAlumno($pdo, $id) {
    $stmt = $pdo->prepare("DELETE FROM alumnos WHERE id = ?");
    return $stmt->execute([$id]);
}
?>