<?php
require 'conexion.php';
require 'funciones.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $grupoId = $_POST['grupo_id'];
    $archivo = $_FILES['excel_file']['tmp_name'];
    $nombreArchivo = $_FILES['excel_file']['name'];
    
    $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));

    if ($extension == 'csv') {
        if (($handle = fopen($archivo, "r")) !== FALSE) {
            $stmt = $pdo->prepare("INSERT INTO alumnos (nombre, grupo_id, estatus) VALUES (?, ?, 'Pendiente')");
            
            while (($datos = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $nombre = trim($datos[0]); // Asumimos que el nombre está en la primera columna
                if (!empty($nombre)) {
                    $stmt->execute([$nombre, $grupoId]);
                }
            }
            fclose($handle);
            
            header("Location: detalle_grupo.php?id=$grupoId&mensaje=Importación de nombres completada");
            exit();
        } else {
            header("Location: detalle_grupo.php?id=$grupoId&mensaje=Error al abrir el archivo");
            exit();
        }
    } else {
        header("Location: detalle_grupo.php?id=$grupoId&mensaje=Formato de archivo no soportado. Por favor, use CSV.");
        exit();
    }
}
?>