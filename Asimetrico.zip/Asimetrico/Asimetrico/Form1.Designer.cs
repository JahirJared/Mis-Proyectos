﻿
namespace Asimetrico
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ClvPublica = new System.Windows.Forms.TextBox();
            this.ClvPrivada = new System.Windows.Forms.TextBox();
            this.MsjEnviar = new System.Windows.Forms.TextBox();
            this.ClvPublicaEmisor = new System.Windows.Forms.TextBox();
            this.MsjCifrado = new System.Windows.Forms.TextBox();
            this.MjsDecifrado = new System.Windows.Forms.TextBox();
            this.ClvPrivadaReceptor = new System.Windows.Forms.TextBox();
            this.GnrLlv = new System.Windows.Forms.Button();
            this.CfrYEnv = new System.Windows.Forms.Button();
            this.DescMsj = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ClvPublica
            // 
            this.ClvPublica.BackColor = System.Drawing.Color.Gray;
            this.ClvPublica.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClvPublica.ForeColor = System.Drawing.Color.MistyRose;
            this.ClvPublica.Location = new System.Drawing.Point(73, 97);
            this.ClvPublica.Multiline = true;
            this.ClvPublica.Name = "ClvPublica";
            this.ClvPublica.Size = new System.Drawing.Size(206, 121);
            this.ClvPublica.TabIndex = 0;
            // 
            // ClvPrivada
            // 
            this.ClvPrivada.BackColor = System.Drawing.Color.Gray;
            this.ClvPrivada.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClvPrivada.ForeColor = System.Drawing.Color.MistyRose;
            this.ClvPrivada.Location = new System.Drawing.Point(352, 97);
            this.ClvPrivada.Multiline = true;
            this.ClvPrivada.Name = "ClvPrivada";
            this.ClvPrivada.Size = new System.Drawing.Size(206, 121);
            this.ClvPrivada.TabIndex = 1;
            // 
            // MsjEnviar
            // 
            this.MsjEnviar.BackColor = System.Drawing.Color.Gray;
            this.MsjEnviar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MsjEnviar.ForeColor = System.Drawing.Color.MistyRose;
            this.MsjEnviar.Location = new System.Drawing.Point(73, 303);
            this.MsjEnviar.Multiline = true;
            this.MsjEnviar.Name = "MsjEnviar";
            this.MsjEnviar.Size = new System.Drawing.Size(206, 121);
            this.MsjEnviar.TabIndex = 2;
            // 
            // ClvPublicaEmisor
            // 
            this.ClvPublicaEmisor.BackColor = System.Drawing.Color.Gray;
            this.ClvPublicaEmisor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClvPublicaEmisor.ForeColor = System.Drawing.Color.MistyRose;
            this.ClvPublicaEmisor.Location = new System.Drawing.Point(73, 498);
            this.ClvPublicaEmisor.Multiline = true;
            this.ClvPublicaEmisor.Name = "ClvPublicaEmisor";
            this.ClvPublicaEmisor.Size = new System.Drawing.Size(206, 121);
            this.ClvPublicaEmisor.TabIndex = 3;
            // 
            // MsjCifrado
            // 
            this.MsjCifrado.BackColor = System.Drawing.Color.Gray;
            this.MsjCifrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MsjCifrado.ForeColor = System.Drawing.Color.MistyRose;
            this.MsjCifrado.Location = new System.Drawing.Point(352, 303);
            this.MsjCifrado.Multiline = true;
            this.MsjCifrado.Name = "MsjCifrado";
            this.MsjCifrado.Size = new System.Drawing.Size(206, 250);
            this.MsjCifrado.TabIndex = 4;
            // 
            // MjsDecifrado
            // 
            this.MjsDecifrado.BackColor = System.Drawing.Color.Gray;
            this.MjsDecifrado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MjsDecifrado.ForeColor = System.Drawing.Color.MistyRose;
            this.MjsDecifrado.Location = new System.Drawing.Point(618, 303);
            this.MjsDecifrado.Multiline = true;
            this.MjsDecifrado.Name = "MjsDecifrado";
            this.MjsDecifrado.Size = new System.Drawing.Size(206, 121);
            this.MjsDecifrado.TabIndex = 5;
            // 
            // ClvPrivadaReceptor
            // 
            this.ClvPrivadaReceptor.BackColor = System.Drawing.Color.Gray;
            this.ClvPrivadaReceptor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClvPrivadaReceptor.ForeColor = System.Drawing.Color.MistyRose;
            this.ClvPrivadaReceptor.Location = new System.Drawing.Point(618, 498);
            this.ClvPrivadaReceptor.Multiline = true;
            this.ClvPrivadaReceptor.Name = "ClvPrivadaReceptor";
            this.ClvPrivadaReceptor.Size = new System.Drawing.Size(206, 121);
            this.ClvPrivadaReceptor.TabIndex = 6;
            // 
            // GnrLlv
            // 
            this.GnrLlv.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.GnrLlv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GnrLlv.ForeColor = System.Drawing.Color.MistyRose;
            this.GnrLlv.Location = new System.Drawing.Point(648, 123);
            this.GnrLlv.Name = "GnrLlv";
            this.GnrLlv.Size = new System.Drawing.Size(158, 58);
            this.GnrLlv.TabIndex = 7;
            this.GnrLlv.Text = "Generar Llaves";
            this.GnrLlv.UseVisualStyleBackColor = false;
            this.GnrLlv.Click += new System.EventHandler(this.GnrLlv_Click);
            // 
            // CfrYEnv
            // 
            this.CfrYEnv.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.CfrYEnv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.CfrYEnv.ForeColor = System.Drawing.Color.MistyRose;
            this.CfrYEnv.Location = new System.Drawing.Point(91, 656);
            this.CfrYEnv.Name = "CfrYEnv";
            this.CfrYEnv.Size = new System.Drawing.Size(158, 58);
            this.CfrYEnv.TabIndex = 8;
            this.CfrYEnv.Text = "Cifrar y Enviar";
            this.CfrYEnv.UseVisualStyleBackColor = false;
            this.CfrYEnv.Click += new System.EventHandler(this.CfrYEnv_Click);
            // 
            // DescMsj
            // 
            this.DescMsj.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.DescMsj.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DescMsj.ForeColor = System.Drawing.Color.MistyRose;
            this.DescMsj.Location = new System.Drawing.Point(648, 656);
            this.DescMsj.Name = "DescMsj";
            this.DescMsj.Size = new System.Drawing.Size(158, 58);
            this.DescMsj.TabIndex = 9;
            this.DescMsj.Text = "Desencriptar Mensaje";
            this.DescMsj.UseVisualStyleBackColor = false;
            this.DescMsj.Click += new System.EventHandler(this.DescMsj_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Firebrick;
            this.label1.Location = new System.Drawing.Point(100, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 29);
            this.label1.TabIndex = 10;
            this.label1.Text = "Clave Publica";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(82, 248);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 29);
            this.label2.TabIndex = 11;
            this.label2.Text = "Mensaje a Enviar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Firebrick;
            this.label3.Location = new System.Drawing.Point(39, 450);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(282, 29);
            this.label3.TabIndex = 12;
            this.label3.Text = "Clave Publica del Emisor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(369, 248);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(189, 29);
            this.label4.TabIndex = 13;
            this.label4.Text = "Mensaje Cifrado";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label5.Location = new System.Drawing.Point(379, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 29);
            this.label5.TabIndex = 14;
            this.label5.Text = "Clave Privada";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(613, 248);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(215, 29);
            this.label6.TabIndex = 15;
            this.label6.Text = "Mensaje Decifrado";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label7.Location = new System.Drawing.Point(577, 450);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(306, 29);
            this.label7.TabIndex = 16;
            this.label7.Text = "Clave Privada del Receptor";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 726);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DescMsj);
            this.Controls.Add(this.CfrYEnv);
            this.Controls.Add(this.GnrLlv);
            this.Controls.Add(this.ClvPrivadaReceptor);
            this.Controls.Add(this.MjsDecifrado);
            this.Controls.Add(this.MsjCifrado);
            this.Controls.Add(this.ClvPublicaEmisor);
            this.Controls.Add(this.MsjEnviar);
            this.Controls.Add(this.ClvPrivada);
            this.Controls.Add(this.ClvPublica);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox ClvPublica;
        private System.Windows.Forms.TextBox ClvPrivada;
        private System.Windows.Forms.TextBox MsjEnviar;
        private System.Windows.Forms.TextBox ClvPublicaEmisor;
        private System.Windows.Forms.TextBox MsjCifrado;
        private System.Windows.Forms.TextBox MjsDecifrado;
        private System.Windows.Forms.TextBox ClvPrivadaReceptor;
        private System.Windows.Forms.Button GnrLlv;
        private System.Windows.Forms.Button CfrYEnv;
        private System.Windows.Forms.Button DescMsj;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}

