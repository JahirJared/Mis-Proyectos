﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace Asimetrico
{
    public partial class Form1 : Form
    {

        string llavePublica;
        string llavePrivada;

        public Form1()
        {
            InitializeComponent();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void GnrLlv_Click(object sender, EventArgs e)
        {
            RSACryptoServiceProvider rsa = new RSACryptoServiceProvider();
            llavePublica = rsa.ToXmlString(false); //llave publica
            llavePrivada = rsa.ToXmlString(true); //llave privada
            ClvPublica.Text = llavePublica;
            ClvPrivada.Text = llavePrivada;
        }

        private void CfrYEnv_Click(object sender, EventArgs e)
        {
            MsjCifrado.Text = Cifrar(ClvPublicaEmisor.Text,MsjEnviar.Text,"archivoCifrado.dat");
        }

        public string Cifrar(string llavePublica, string Texto, string NombreArchivo)
        {
            UnicodeEncoding byteConverter = new UnicodeEncoding();
            byte[] textoBytes = byteConverter.GetBytes(Texto);

            byte[] datos_encriptados;
            using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
            {
                rsa.FromXmlString(llavePublica);
                datos_encriptados = rsa.Encrypt(textoBytes, false);
            }

            File.WriteAllBytes(NombreArchivo, datos_encriptados);
            string bytes = "";

            foreach (byte a in datos_encriptados)
            {
                bytes = bytes + " " + Convert.ToChar(a);
            }
            return bytes;
        }

        private void DescMsj_Click(object sender, EventArgs e)
        {
            MjsDecifrado.Text = Descifrar(ClvPrivadaReceptor.Text, "archivoCifrado.dat");
        }
        public string Descifrar(string llavePrivada, string nombreArchivo)
        {
            byte[] datosEncriptados = File.ReadAllBytes(nombreArchivo);
            byte[] datosDesencriptados = null;

            try
            {
                using (RSACryptoServiceProvider rsa = new RSACryptoServiceProvider())
                {
                    rsa.FromXmlString(llavePrivada);
                    datosDesencriptados = rsa.Decrypt(datosEncriptados, false);
                 }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al Desencriptar");
            }
            UnicodeEncoding byteConverter = new UnicodeEncoding();
            return byteConverter.GetString(datosDesencriptados);
        }
    }
}
