﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;

namespace Modelos
{
    public class Persona
    {
        public string nombre { get; set; }
        public int edad { get; set; }
        public string nacionalidad { get; set; }


        public string Guardar(Persona p)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=DESKTOP-B4MJ7IA;Initial Catalog=Personas;Integrated Security=True";

            SqlCommand comando = new SqlCommand();
            comando.CommandText = "Insert into Personas(Nombre,Edad,Nacionalidad)Values('"+p.nombre+"',"+p.edad+",'"+ p.nacionalidad+"')";
            comando.Connection = con;
            con.Open();
            int res = comando.ExecuteNonQuery();
            con.Close();
            return "Guardado";
        }
        public DataTable obtenerPersonas()
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=DESKTOP-B4MJ7IA;Initial Catalog=Personas;Integrated Security=True";

            String query = "Select *from Personas";
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(query,con);
            DataTable tabla = new DataTable();
            da.Fill(tabla);

            return tabla;
        }
        public int Eliminar(int id)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=DESKTOP-B4MJ7IA;Initial Catalog=Personas;Integrated Security=True";
            string query = "Delete from Personas where id=" + id;
            SqlCommand comando = new SqlCommand(query,con);

            con.Open();
            int res = comando.ExecuteNonQuery();
            con.Close();
            return res;
        }
        public string Actualizar(int id, Persona p)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = @"Data Source=DESKTOP-B4MJ7IA;Initial Catalog=Personas;Integrated Security=True";

            SqlCommand comando = new SqlCommand();
            comando.CommandText = "Update Personas set nombre='" + p.nombre + "',edad=" + p.edad + ",nacionalidad='" + p.nacionalidad + "'from Personas where id=" + id;
            comando.Connection = con;
            con.Open();
            int res = comando.ExecuteNonQuery();
            con.Close();

            return "Registro actualizado";
        }


    }
}