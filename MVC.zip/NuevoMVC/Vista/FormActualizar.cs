﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Modelos;
using Controlador;

namespace Vista
{
    public partial class FormActualizar : Form
    {
        int id;
        Persona p;
        public FormActualizar(int _id, Persona _p)
        {
            InitializeComponent();
            id = _id;
            p = _p;
        }

        private void btnActualizar_Click(object sender, EventArgs e)
            {
                Persona p = new Persona();
                p.nombre = txtNombre.Text;
                p.edad = int.Parse(txtEdad.Text);
                p.nacionalidad = cmbNacionalidad.SelectedItem.ToString();

                string res = PersonaController.actualizarPersona(id, p);
                MessageBox.Show(res);
            this.DialogResult = DialogResult.OK;
            this.Close();
            }

        private void FormActualizar_Load_1(object sender, EventArgs e)
        {
            txtNombre.Text = p.nombre;
            txtEdad.Text = p.edad.ToString();
            cmbNacionalidad.Text = p.nacionalidad;
        }

        private void cmbNacionalidad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
    }
