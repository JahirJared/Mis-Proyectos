﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Controlador;
using Modelos;

namespace Vista
{
    public partial class Form1 : Form
    {

        DataTable tabla;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tabla = new DataTable();
            tabla.Columns.Add("Nombre");
            tabla.Columns.Add("Edad");
            tabla.Columns.Add("Nacionalidad");

            dataGridView1.DataSource = tabla;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            tabla = new DataTable();
            tabla.Columns.Add("Nombre");
            tabla.Columns.Add("Edad");
            tabla.Columns.Add("Nacionalidad");

            dataGridView1.DataSource = tabla;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            Persona p = new Persona();
            p.nombre = txtNombre.Text;
            p.edad = int.Parse(txtEdad.Text);
            p.nacionalidad = cmbNacionalidad.SelectedItem.ToString();

            string respuesta = PersonaController.GuardarPersona(p);

            CargarGrid();
        }

        private void txtNombre_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEdad_TextChanged(object sender, EventArgs e)
        {

        }

        private void cmbNacionalidad_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            CargarGrid();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        public void CargarGrid()
        {
            dataGridView1.DataSource = PersonaController.consultarPersonas();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int fila = dataGridView1.SelectedCells[0].RowIndex;
            int id = int.Parse(dataGridView1.Rows[fila].Cells[0].Value.ToString());
            int res = PersonaController.borrarPersona(id);
            if (res == 1)
            {
                MessageBox.Show("Registro borrado");
                CargarGrid();
            }
            else
            {
                MessageBox.Show("Ocurrio un error al borrar");
            }
    }

    private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            int fila = dataGridView1.SelectedCells[0].RowIndex;
            int id = int.Parse(dataGridView1.Rows[fila].Cells[0].Value.ToString());

            Persona p = new Persona();
            p.nombre = dataGridView1.Rows[fila].Cells[1].Value.ToString();
            p.edad = int.Parse(dataGridView1.Rows[fila].Cells[2].Value.ToString());
            p.nacionalidad = dataGridView1.Rows[fila].Cells[3].Value.ToString();
            FormActualizar form = new FormActualizar(id, p);
            form.ShowDialog();

            if(form.DialogResult == DialogResult.OK)
            {
                CargarGrid();
            }

        }
    }
}