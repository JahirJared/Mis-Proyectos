﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modelos;
using System.Data;

namespace Controlador
{
    public class PersonaController
    {
        public static string GuardarPersona(Persona p)
        {
            if (string.IsNullOrEmpty(p.nombre))
            {
                return "Nombre vacío";
            }
            else if (p.edad < 18)
            {
                return "La edad debe ser mayor o igual a 18";
            }
            Persona persona1 = new Persona();
            return persona1.Guardar(p);
        }
        public static DataTable consultarPersonas()
        {
            Persona p = new Persona();
            return p.obtenerPersonas();
        }
        public static int borrarPersona(int id)
        {
            Persona p = new Persona();
            return p.Eliminar(id);
        }
        public static string actualizarPersona(int id, Persona p)
        {
            Persona per = new Persona();
            return per.Actualizar(id, p);
        }
    }
}