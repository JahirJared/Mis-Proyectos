<?php
session_start();

class Vehiculo {
    public $marca;
    public $modelo;
    public $año;
    public $estado = "apagado";

    public function __construct($marca, $modelo, $año) {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->año = $año;
    }

    public function encender() {
        $this->estado = "encendido";
        return "El vehículo se ha encendido";
    }

    public function apagar() {
        $this->estado = "apagado";
        return "El vehículo se ha apagado";
    }

    public function arrancar() {
        if ($this->estado === "encendido") {
            return "El vehículo ha arrancado";
        } else {
            return "El vehículo está apagado";
        }
    }

    public function detener() {
        if ($this->estado === "encendido") {
            return "El vehículo se ha detenido";
        } else {
            return "El vehículo está apagado";
        }
    }

    public function acelerar() {
        if ($this->estado === "encendido") {
            return "El vehículo ha acelerado";
        } else {
            return "El vehículo está apagado";
        }
    }

    public function retroceder() {
        if ($this->estado === "encendido") {
            return "El vehículo ha retrocedido";
        } else {
            return "El vehículo está apagado";
        }
    }

    public function girarIzquierda() {
        if ($this->estado === "encendido") {
            return "El vehículo ha girado a la izquierda";
        } else {
            return "El vehículo está apagado";
        }
    }

    public function girarDerecha() {
        if ($this->estado === "encendido") {
            return "El vehículo ha girado a la derecha";
        } else {
            return "El vehículo está apagado";
        }
    }

    public function activarLuces() {
        if ($this->estado === "encendido") {
            return "Las luces del vehículo están encendidas";
        } else {
            return "El vehículo está apagado";
        }
    }
}

if (!isset($_SESSION['vehiculo'])) {
    $_SESSION['vehiculo'] = serialize(new Vehiculo("Toyota", "Corolla", 2020));
}

$miVehiculo = unserialize($_SESSION['vehiculo']);

if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'encender':
            $output = $miVehiculo->encender();
            break;
        case 'apagar':
            $output = $miVehiculo->apagar();
            break;
        case 'acelerar':
            $output = $miVehiculo->acelerar();
            break;
        case 'retroceder':
            $output = $miVehiculo->retroceder();
            break;
        case 'girar_izquierda':
            $output = $miVehiculo->girarIzquierda();
            break;
        case 'girar_derecha':
            $output = $miVehiculo->girarDerecha();
            break;
        case 'luces':
            $output = $miVehiculo->activarLuces();
            break;
        default:
            $output = "Acción no reconocida";
            break;
    }
    $_SESSION['vehiculo'] = serialize($miVehiculo);
    echo $output;
    exit();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control del Vehículo</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            overflow: hidden;
        }
        #output {
            font-size: 20px;
            margin-top: 20px;
        }
        #instructions {
            display: none;
        }
        #startButton {
            font-size: 20px;
            padding: 10px 20px;
            cursor: pointer;
        }
        #vehicle {
            width: 100px;
            height: 50px;
            background-color: blue;
            margin: 20px auto;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            transition: all 0.2s;
            border-radius: 10px;
        }
        .wheel {
            width: 20px;
            height: 20px;
            background-color: black;
            border-radius: 50%;
            position: absolute;
        }
        .wheel.front-left {
            top: -5px;
            left: 10px;
        }
        .wheel.front-right {
            top: -5px;
            right: 10px;
        }
        .wheel.back-left {
            bottom: -5px;
            left: 10px;
        }
        .wheel.back-right {
            bottom: -5px;
            right: 10px;
        }
        .headlight {
            width: 10px;
            height: 10px;
            background-color: yellow;
            position: absolute;
            display: none;
        }
        .headlight.left {
            top: -5px;
            left: 15px;
        }
        .headlight.right {
            top: -5px;
            right: 15px;
        }
        .smoke {
            width: 10px;
            height: 10px;
            background-color: gray;
            border-radius: 50%;
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            display: none;
            animation: smokeAnimation 1s infinite;
        }
        @keyframes smokeAnimation {
            0% {
                opacity: 1;
                transform: translateY(0) scale(1);
            }
            100% {
                opacity: 0;
                transform: translateY(-20px) scale(2);
            }
        }
    </style>
</head>
<body>
    <h1>Control del Vehículo</h1>
    <button id="startButton">Iniciar</button>
    <div id="instructions">
        <h2>Teclas y Funciones</h2>
        <ul>
            <li>W: Acelerar (Mover hacia arriba)</li>
            <li>S: Retroceder (Mover hacia abajo)</li>
            <li>Flecha Arriba: Mirar hacia arriba</li>
            <li>Flecha Abajo: Mirar hacia abajo</li>
            <li>Flecha Izquierda: Girar a la Izquierda</li>
            <li>Flecha Derecha: Girar a la Derecha</li>
            <li>I: Encender el Vehículo</li>
            <li>O: Apagar el Vehículo</li>
            <li>L: Activar Luces</li>
        </ul>
    </div>
    <div id="output">
        <h2>Acciones del Vehículo</h2>
        <p id="vehicleActions">Esperando acción...</p>
    </div>
    <div id="vehicle">
        <div class="wheel front-left"></div>
        <div class="wheel front-right"></div>
        <div class="wheel back-left"></div>
        <div class="wheel back-right"></div>
        <div class="headlight left"></div>
        <div class="headlight right"></div>
        <div class="smoke"></div>
    </div>
    <script>
        document.getElementById('startButton').addEventListener('click', function() {
            document.getElementById('instructions').style.display = 'block';
            document.getElementById('startButton').style.display = 'none';
        });

        let vehicle = document.getElementById('vehicle');
        let headlights = document.querySelectorAll('.headlight');
        let smoke = document.querySelector('.smoke');
        let vehicleState = "apagado";
        let vehicleSpeed = 10;

        document.addEventListener('keydown', function(event) {
            let action = '';
            switch(event.key.toLowerCase()) {
                case 'w':
                    action = 'acelerar';
                    if (vehicleState === "encendido") {
                        vehicle.style.top = (vehicle.offsetTop - vehicleSpeed) + 'px';
                    }
                    break;
                case 's':
                    action = 'retroceder';
                    if (vehicleState === "encendido") {
                        vehicle.style.top = (vehicle.offsetTop + vehicleSpeed) + 'px';
                    }
                    break;
                case 'arrowup':
                    vehicle.style.transform = 'rotate(-90deg)';
                    break;
                case 'arrowdown':
                    vehicle.style.transform = 'rotate(90deg)';
                    break;
                case 'arrowleft':
                    vehicle.style.transform = 'rotate(180deg)';
                    break;
                case 'arrowright':
                    vehicle.style.transform = 'rotate(0deg)';
                    break;
                case 'i':
                    action = 'encender';
                    vehicleState = "encendido";
                    headlights.forEach(headlight => headlight.style.display = 'block');
                    smoke.style.display = 'block';
                    break;
                case 'o':
                    action = 'apagar';
                    vehicleState = "apagado";
                    headlights.forEach(headlight => headlight.style.display = 'none');
                    smoke.style.display = 'none';
                    break;
                case 'l':
                    action = 'luces';
                    headlights.forEach(headlight => headlight.style.display = (headlight.style.display === 'none') ? 'block' : 'none');
                    break;
                default:
                    return;
            }

            fetch(`index.php?action=${action}`)
                .then(response => response.text())
                .then(data => {
                    document.getElementById('vehicleActions').innerText = data;
                });

            // Colisión y límites de la pantalla
            checkBounds();
        });

        // Colisión y límites de la pantalla
        function checkBounds() {
            let vehicleRect = vehicle.getBoundingClientRect();
            if (vehicleRect.top < 0) vehicle.style.top = '0px';
            if (vehicleRect.left < 0) vehicle.style.left = '0px';
            if (vehicleRect.bottom > window.innerHeight) vehicle.style.top = (window.innerHeight - vehicleRect.height) + 'px';
            if (vehicleRect.right > window.innerWidth) vehicle.style.left = (window.innerWidth - vehicleRect.width) + 'px';
        }
    </script>
</body>
</html>
