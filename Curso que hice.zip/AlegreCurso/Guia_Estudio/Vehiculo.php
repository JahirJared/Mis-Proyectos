<?php

class Vehiculo {
    private $marca;
    private $modelo;
    private $año;
    private $estado = "apagado";
    private $velocidad = 0;
    private $angulo = 0;

    public function __construct($marca, $modelo, $año) {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->año = $año;
    }

    public function getMarca() {
        return $this->marca;
    }

    public function getModelo() {
        return $this->modelo;
    }

    public function getAño() {
        return $this->año;
    }

    public function getEstado() {
        return $this->estado;
    }

    public function getVelocidad() {
        return $this->velocidad;
    }

    public function getAngulo() {
        return $this->angulo;
    }

    public function encender() {
        if ($this->estado === "apagado") {
            $this->estado = "encendido";
            return "El vehículo se ha encendido.";
        } else {
            return "El vehículo ya está encendido.";
        }
    }

    public function apagar() {
        if ($this->estado === "encendido") {
            $this->estado = "apagado";
            $this->velocidad = 0;
            return "El vehículo se ha apagado.";
        } else {
            return "El vehículo ya está apagado.";
        }
    }

    public function acelerar() {
        if ($this->estado === "encendido") {
            $this->velocidad += 10;
            return "El vehículo ha acelerado. Velocidad actual: " . $this->velocidad . " km/h.";
        } else {
            return "No se puede acelerar, el vehículo está apagado.";
        }
    }

    public function frenar() {
        if ($this->estado === "encendido") {
            if ($this->velocidad >= 10) {
                $this->velocidad -= 10;
            } else {
                $this->velocidad = 0;
            }
            return "El vehículo ha frenado. Velocidad actual: " . $this->velocidad . " km/h.";
        } else {
            return "No se puede frenar, el vehículo está apagado.";
        }
    }

    public function girarIzquierda() {
        if ($this->estado === "encendido") {
            $this->angulo -= 10;
            return "El vehículo ha girado a la izquierda. Ángulo actual: " . $this->angulo . " grados.";
        } else {
            return "No se puede girar a la izquierda, el vehículo está apagado.";
        }
    }

    public function girarDerecha() {
        if ($this->estado === "encendido") {
            $this->angulo += 10;
            return "El vehículo ha girado a la derecha. Ángulo actual: " . $this->angulo . " grados.";
        } else {
            return "No se puede girar a la derecha, el vehículo está apagado.";
        }
    }

    public function detener() {
        if ($this->estado === "encendido") {
            $this->velocidad = 0;
            return "El vehículo se ha detenido.";
        } else {
            return "El vehículo está apagado.";
        }
    }
}

$miVehiculo = new Vehiculo("Toyota", "Corolla", 2020);

echo $miVehiculo->encender() . "<br>";
echo $miVehiculo->acelerar() . "<br>";
echo $miVehiculo->acelerar() . "<br>";
echo $miVehiculo->frenar() . "<br>";
echo $miVehiculo->girarIzquierda() . "<br>";
echo $miVehiculo->girarDerecha() . "<br>";
echo $miVehiculo->detener() . "<br>";
echo $miVehiculo->apagar() . "<br>";

?>
