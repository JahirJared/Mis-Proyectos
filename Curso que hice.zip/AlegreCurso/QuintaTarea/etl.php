<?php
// Ruta del archivo CSV
$csvFile = 'datos_origen.csv';

// Abrir el archivo CSV
$csvData = array_map('str_getcsv', file($csvFile));

// Mostrar los datos extraídos
echo "Datos Extraídos:<br>";
foreach ($csvData as $row) {
    echo implode(", ", $row) . "<br>";
}
?>

<?php

// Función para limpiar y transformar datos
function transformData($data) {
    $transformedData = [];

    foreach ($data as $row) {
        // Limpiar datos (por ejemplo, eliminar filas con valores nulos)
        if (!in_array(null, $row)) {
            // Transformar datos (por ejemplo, convertir todas las letras a minúsculas en una columna específica)
            $row[1] = strtolower($row[1]);
            $transformedData[] = $row;
        }
    }

    return $transformedData;
}

// Transformar los datos
$transformedData = transformData($csvData);

// Mostrar los datos transformados
echo "Datos Transformados:<br>";
foreach ($transformedData as $row) {
    echo implode(", ", $row) . "<br>";
}
?>

<?php

// Conectar a la base de datos MySQL
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "base_datos_destino";

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Crear la tabla de destino si no existe
$sql = "CREATE TABLE IF NOT EXISTS tabla_destino (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    columna1 VARCHAR(30) NOT NULL,
    columna2 VARCHAR(30) NOT NULL
)";

if ($conn->query($sql) !== TRUE) {
    echo "Error creando tabla: " . $conn->error;
}

// Insertar los datos transformados en la base de datos
$stmt = $conn->prepare("INSERT INTO tabla_destino (columna1, columna2) VALUES (?, ?)");
$stmt->bind_param("ss", $columna1, $columna2);

foreach ($transformedData as $row) {
    $columna1 = $row[0];
    $columna2 = $row[1];
    $stmt->execute();
}

echo "Datos Cargados en la Base de Datos<br>";

$stmt->close();
$conn->close();
?>
