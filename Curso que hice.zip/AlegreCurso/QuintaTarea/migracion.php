<?php
$sourceServername = "localhost";
$sourceUsername = "root";
$sourcePassword = "";
$sourceDbname = "datos_origen";

$sourceConn = new mysqli($sourceServername, $sourceUsername, $sourcePassword, $sourceDbname);

if ($sourceConn->connect_error) {
    die("Conexión a la base de datos de origen fallida: " . $sourceConn->connect_error);
}

// Conectar a la base de datos MySQL de destino
$destServername = "localhost";
$destUsername = "root";
$destPassword = "";
$destDbname = "base_datos_destino";

$destConn = new mysqli($destServername, $destUsername, $destPassword, $destDbname);

if ($destConn->connect_error) {
    die("Conexión a la base de datos de destino fallida: " . $destConn->connect_error);
}

// Lee datos de la tabla de origen
$sql = "SELECT * FROM tabla_origen";
$result = $sourceConn->query($sql);

if ($result->num_rows > 0) {
    // Crear la tabla de destino si no existe
    $sql = "CREATE TABLE IF NOT EXISTS tabla_destino (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        columna1 VARCHAR(30) NOT NULL,
        columna2 VARCHAR(30) NOT NULL
    )";

    if ($destConn->query($sql) !== TRUE) {
        echo "Error creando tabla en la base de datos de destino: " . $destConn->error;
    }

    // Preparar la declaración de inserción
    $stmt = $destConn->prepare("INSERT INTO tabla_destino (columna1, columna2) VALUES (?, ?)");
    $stmt->bind_param("ss", $columna1, $columna2);

    // Insertar datos en la tabla de destino
    while ($row = $result->fetch_assoc()) {
        $columna1 = $row["columna1"];
        $columna2 = $row["columna2"];
        $stmt->execute();
    }

    echo "Datos migrados exitosamente<br>";

    $stmt->close();
} else {
    echo "No se encontraron datos en la tabla de origen<br>";
}

$sourceConn->close();
$destConn->close();
?>
