CREATE DATABASE datos_origen;
USE datos_origen;

CREATE TABLE tabla_origen (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    columna1 VARCHAR(30) NOT NULL,
    columna2 VARCHAR(30) NOT NULL
);

