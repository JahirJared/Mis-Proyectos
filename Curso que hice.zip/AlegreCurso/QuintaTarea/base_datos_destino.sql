CREATE DATABASE base_datos_destino;

USE base_datos_destino;
CREATE TABLE tabla_destino (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    columna1 VARCHAR(30) NOT NULL,
    columna2 VARCHAR(30) NOT NULL
);

select *from tabla_destino;