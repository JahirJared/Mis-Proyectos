<!DOCTYPE html>
<html>
<head>
    <title>Interfaz ETL</title>
</head>
<body>
    <h1>Interfaz de Proceso ETL</h1>
    <form action="etl_complejo_avanzado.php" method="get">
        <button type="submit">Iniciar Proceso ETL</button>
    </form>
    <h2>Log de ETL</h2>
    <pre><?php echo file_get_contents('etl_log.txt'); ?></pre>
</body>
</html>
