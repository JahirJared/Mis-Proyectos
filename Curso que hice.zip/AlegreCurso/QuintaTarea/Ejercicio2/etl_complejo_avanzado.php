<?php
function logMessage($message) {
    file_put_contents('etl_log.txt', $message . PHP_EOL, FILE_APPEND);
}

$sourceServername = "localhost";
$sourceUsername = "root";
$sourcePassword = "";
$sourceDbname = "origen";

$destServername = "localhost";
$destUsername = "root";
$destPassword = "";
$destDbname = "destino";

// Conectar a la base de datos de origen
$sourceConn = new mysqli($sourceServername, $sourceUsername, $sourcePassword, $sourceDbname);
if ($sourceConn->connect_error) {
    die("Conexión fallida a la base de datos de origen: " . $sourceConn->connect_error);
}

// Conectar a la base de datos de destino
$destConn = new mysqli($destServername, $destUsername, $destPassword, $destDbname);
if ($destConn->connect_error) {
    die("Conexión fallida a la base de datos de destino: " . $destConn->connect_error);
}

// Extraer datos de las tablas de origen
$clientesSql = "SELECT * FROM clientes";
$clientesResult = $sourceConn->query($clientesSql);

$ordenesSql = "SELECT cliente_id, MAX(fecha) AS fecha_ultima_orden, SUM(monto) AS monto_total_ordenes FROM ordenes GROUP BY cliente_id";
$ordenesResult = $sourceConn->query($ordenesSql);

$productosSql = "SELECT o.cliente_id, GROUP_CONCAT(p.nombre) AS productos_comprados
                 FROM ordenes o
                 JOIN productos p ON o.id = p.id
                 GROUP BY o.cliente_id";
$productosResult = $sourceConn->query($productosSql);

$ordenesData = [];
while ($row = $ordenesResult->fetch_assoc()) {
    $ordenesData[$row['cliente_id']] = $row;
}

$productosData = [];
while ($row = $productosResult->fetch_assoc()) {
    $productosData[$row['cliente_id']] = $row['productos_comprados'];
}

// Transformar y cargar los datos en la tabla de destino
if ($clientesResult->num_rows > 0) {
    $stmt = $destConn->prepare("INSERT INTO clientes_ordenes_productos (cliente_id, nombre_cliente, email, fecha_ultima_orden, monto_total_ordenes, productos_comprados) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssds", $cliente_id, $nombre_cliente, $email, $fecha_ultima_orden, $monto_total_ordenes, $productos_comprados);

    while ($row = $clientesResult->fetch_assoc()) {
        $cliente_id = $row['id'];
        $nombre_cliente = $row['nombre'];
        $email = $row['email'];
        $fecha_ultima_orden = isset($ordenesData[$cliente_id]['fecha_ultima_orden']) ? $ordenesData[$cliente_id]['fecha_ultima_orden'] : null;
        $monto_total_ordenes = isset($ordenesData[$cliente_id]['monto_total_ordenes']) ? $ordenesData[$cliente_id]['monto_total_ordenes'] : 0;
        $productos_comprados = isset($productosData[$cliente_id]) ? $productosData[$cliente_id] : '';

        // Validación de datos
        if (filter_var($email, FILTER_VALIDATE_EMAIL) && $monto_total_ordenes > 0) {
            $stmt->execute();
        } else {
            logMessage("Datos inválidos para el cliente ID: $cliente_id");
        }
    }

    logMessage("Datos migrados exitosamente.");
    echo "Datos migrados exitosamente.<br>";

    $stmt->close();
} else {
    logMessage("No se encontraron clientes en la base de datos de origen.");
    echo "No se encontraron clientes en la base de datos de origen.<br>";
}

$sourceConn->close();
$destConn->close();
?>
