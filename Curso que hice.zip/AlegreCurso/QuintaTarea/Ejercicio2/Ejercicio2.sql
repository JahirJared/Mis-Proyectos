USE origen;

CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    precio FLOAT
);

-- Insertar datos de prueba
INSERT INTO productos (nombre, precio) VALUES 
('Producto A', 10.50), 
('Producto B', 20.00), 
('Producto C', 15.75);

USE destino;

CREATE TABLE clientes_ordenes_productos (
    cliente_id INT,
    nombre_cliente VARCHAR(100),
    email VARCHAR(100),
    fecha_ultima_orden DATE,
    monto_total_ordenes FLOAT,
    productos_comprados TEXT
);

select *from clientes_ordenes_productos;