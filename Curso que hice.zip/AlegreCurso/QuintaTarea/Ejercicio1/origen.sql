CREATE DATABASE origen;
USE origen;

CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    email VARCHAR(100)
);

CREATE TABLE ordenes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    fecha DATE,
    monto FLOAT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id)
);

-- Insertar datos de prueba
INSERT INTO clientes (nombre, email) VALUES 
('Juan Perez', 'juan@example.com'), 
('Ana Lopez', 'ana@example.com');

INSERT INTO ordenes (cliente_id, fecha, monto) VALUES 
(1, '2023-01-15', 100.50), 
(1, '2023-03-10', 150.75), 
(2, '2023-02-20', 200.00);
