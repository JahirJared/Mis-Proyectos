CREATE DATABASE destino;
USE destino;

CREATE TABLE clientes_ordenes (
    cliente_id INT,
    nombre VARCHAR(100),
    email VARCHAR(100),
    fecha_ultima_orden DATE,
    monto_total_ordenes FLOAT
);

select *From clientes_ordenes;