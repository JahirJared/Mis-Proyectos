<?php
$sourceServername = "localhost";
$sourceUsername = "root";
$sourcePassword = "";
$sourceDbname = "origen";

$destServername = "localhost";
$destUsername = "root";
$destPassword = "";
$destDbname = "destino";

// Conectar a la base de datos de origen
$sourceConn = new mysqli($sourceServername, $sourceUsername, $sourcePassword, $sourceDbname);
if ($sourceConn->connect_error) {
    die("Conexión fallida a la base de datos de origen: " . $sourceConn->connect_error);
}

// Conectar a la base de datos de destino
$destConn = new mysqli($destServername, $destUsername, $destPassword, $destDbname);
if ($destConn->connect_error) {
    die("Conexión fallida a la base de datos de destino: " . $destConn->connect_error);
}

// Extraer datos de las tablas de origen
$clientesSql = "SELECT * FROM clientes";
$clientesResult = $sourceConn->query($clientesSql);

$ordenesSql = "SELECT cliente_id, MAX(fecha) AS fecha_ultima_orden, SUM(monto) AS monto_total_ordenes FROM ordenes GROUP BY cliente_id";
$ordenesResult = $sourceConn->query($ordenesSql);

$ordenesData = [];
while ($row = $ordenesResult->fetch_assoc()) {
    $ordenesData[$row['cliente_id']] = $row;
}

// Transformar y cargar los datos en la tabla de destino
if ($clientesResult->num_rows > 0) {
    $stmt = $destConn->prepare("INSERT INTO clientes_ordenes (cliente_id, nombre, email, fecha_ultima_orden, monto_total_ordenes) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("isssd", $cliente_id, $nombre, $email, $fecha_ultima_orden, $monto_total_ordenes);

    while ($row = $clientesResult->fetch_assoc()) {
        $cliente_id = $row['id'];
        $nombre = $row['nombre'];
        $email = $row['email'];
        $fecha_ultima_orden = isset($ordenesData[$cliente_id]['fecha_ultima_orden']) ? $ordenesData[$cliente_id]['fecha_ultima_orden'] : null;
        $monto_total_ordenes = isset($ordenesData[$cliente_id]['monto_total_ordenes']) ? $ordenesData[$cliente_id]['monto_total_ordenes'] : 0;

        $stmt->execute();
    }

    echo "Datos migrados exitosamente.<br>";

    $stmt->close();
} else {
    echo "No se encontraron clientes en la base de datos de origen.<br>";
}

$sourceConn->close();
$destConn->close();
?>
