<?php
include 'config.php';
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = validarEntrada($_POST['nombre']);
    $email = validarEntrada($_POST['email']);
    $edad = validarEntrada($_POST['edad']);

    if (!empty($nombre) && !empty($email) && !empty($edad) && filter_var($email, FILTER_VALIDATE_EMAIL) && is_numeric($edad) && $edad > 0) {
        $stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, edad) VALUES (?, ?, ?)");
        if ($stmt === false) {
            mostrarError($conn->error);
        } else {
            $stmt->bind_param("ssi", $nombre, $email, $edad);

            if ($stmt->execute()) {
                echo "Registro creado con éxito.";
            } else {
                mostrarError($stmt->error);
            }

            $stmt->close();
        }
    } else {
        mostrarError("Datos inválidos. Asegúrese de que todos los campos estén llenos correctamente.");
    }
}
$conn->close();
?>
