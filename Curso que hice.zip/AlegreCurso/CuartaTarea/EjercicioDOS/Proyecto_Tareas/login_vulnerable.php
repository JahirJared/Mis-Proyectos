<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = $_POST['usuario'];
    $password = $_POST['password'];

    // Corregir la consulta SQL
    $sql = "SELECT * FROM usuarios WHERE username='$usuario' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "Login exitoso.";
    } else {
        echo "Usuario o contraseña incorrectos.";
    }
}
?>
