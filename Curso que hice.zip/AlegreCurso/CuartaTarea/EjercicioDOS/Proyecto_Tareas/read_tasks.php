<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';

?>

<!DOCTYPE html>
<html>
<head>
    <title>Ver Tareas</title>
</head>
<body>
    <h1>Ver Tareas</h1>
    <?php
    $stmt = $conn->prepare("SELECT * FROM tareas WHERE usuario=?");
    $stmt->bind_param("s", $_SESSION['username']); // Vincular parámetros
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<strong>Título:</strong> " . htmlspecialchars($row["titulo"]) . "<br>";
            echo "<strong>Descripción:</strong> " . htmlspecialchars($row["descripcion"]) . "<br>";
            echo "<a href='update_task.php?id=" . htmlspecialchars($row["id"]) . "'>Actualizar</a> ";
            echo "<a href='delete_task.php?id=" . htmlspecialchars($row["id"]) . "'>Eliminar</a><br><br>";
        }
    } else {
        echo "No hay tareas.";
    }

    $stmt->close(); // Cerrar la declaración
    ?>
    <a href="index.php">Volver</a>
</body>
</html>
