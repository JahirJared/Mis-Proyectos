<?php
include 'config.php';
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = validarEntrada($_POST['username']);
    $password = validarEntrada($_POST['password']);

    if (!empty($username) && !empty($password)) {
        $password_hashed = password_hash($password, PASSWORD_DEFAULT); // Hashear la contraseña
        $stmt = $conn->prepare("INSERT INTO usuarios (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $password_hashed); // Vincular parámetros

        if ($stmt->execute()) {
            echo "Registro exitoso. <a href='login.php'>Iniciar sesión</a>";
        } else {
            mostrarError($stmt->error); // Mostrar errores de ejecución
        }

        $stmt->close(); // Cerrar la declaración
    } else {
        mostrarError("Todos los campos son obligatorios."); // Validar campos obligatorios
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registro de Usuario</title>
</head>
<body>
    <h1>Registro de Usuario</h1>
    <form method="post" action="register.php">
        Nombre de usuario: <input type="text" name="username" required><br>
        Contraseña: <input type="password" name="password" required><br>
        <input type="submit" value="Registrar">
    </form>
</body>
</html>
