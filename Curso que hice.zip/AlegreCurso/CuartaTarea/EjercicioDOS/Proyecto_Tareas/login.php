<?php
include 'config.php';
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = validarEntrada($_POST['username']);
    $password = validarEntrada($_POST['password']);

    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("SELECT * FROM usuarios WHERE username=?");
        $stmt->bind_param("s", $username); // Vincular parámetros
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $username; // Iniciar sesión
                header("Location: index.php");
            } else {
                mostrarError("Contraseña incorrecta."); // Verificar contraseña
            }
        } else {
            mostrarError("Usuario no encontrado."); // Verificar existencia del usuario
        }

        $stmt->close(); // Cerrar la declaración
    } else {
        mostrarError("Todos los campos son obligatorios."); // Validar campos obligatorios
    }
}
?>

<!DOCTYPE html>
<html>
head>
    <title>Iniciar Sesión</title>
</head>
<body>
    <h1>Iniciar Sesión</h1>
    <form method="post" action="login.php">
        Nombre de usuario: <input type="text" name="username" required><br>
        Contraseña: <input type="password" name="password" required><br>
        <input type="submit" value="Iniciar Sesión">
    </form>
</body>
</html>
