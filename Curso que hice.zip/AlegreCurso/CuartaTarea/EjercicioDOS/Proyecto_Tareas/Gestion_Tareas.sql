CREATE DATABASE gestion_tareas;

USE gestion_tareas;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE tareas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(100) NOT NULL,
    descripcion TEXT NOT NULL,
    usuario VARCHAR(50) NOT NULL,
    FOREIGN KEY (usuario) REFERENCES usuarios(username)
);

INSERT INTO usuarios (username, password) VALUES ('Jahir Jared', '$2y$10$8r9pxLOebMW5Xh.fGtFtBun5DN26Bcr2ZIbkBnv7X8v2K.HWYIxiS');

