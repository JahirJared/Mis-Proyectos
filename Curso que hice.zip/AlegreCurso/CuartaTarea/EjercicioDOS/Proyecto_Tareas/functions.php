<?php
// Función para validar y sanitizar entradas
function validarEntrada($data) {
    $data = trim($data); // Eliminar espacios en blanco
    $data = stripslashes($data); // Eliminar barras invertidas
    $data = htmlspecialchars($data); // Convertir caracteres especiales en entidades HTML
    return $data;
}

// Función para mostrar errores de manera consistente
function mostrarError($mensaje) {
    echo "<p style='color:red;'>Error: $mensaje</p>";
}
?>
