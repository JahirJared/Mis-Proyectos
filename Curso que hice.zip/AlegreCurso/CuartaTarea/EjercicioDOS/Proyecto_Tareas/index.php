<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Gestión de Tareas</title>
</head>
<body>
    <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['username']); ?></h1>
    <a href="create_task.php">Crear Tarea</a>
    <a href="read_tasks.php">Ver Tareas</a>
    <a href="logout.php">Cerrar Sesión</a>
</body>
</html>
