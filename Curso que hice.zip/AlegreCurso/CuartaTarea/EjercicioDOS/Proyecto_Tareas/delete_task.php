<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';
include 'functions.php';

if (isset($_GET['id'])) {
    $id = validarEntrada($_GET['id']);

    $stmt = $conn->prepare("DELETE FROM tareas WHERE id=? AND usuario=?");
    $stmt->bind_param("is", $id, $_SESSION['username']); // Vincular parámetros

    if ($stmt->execute()) {
        echo "Tarea eliminada con éxito.";
    } else {
        mostrarError($stmt->error); // Mostrar errores de ejecución
    }

    $stmt->close(); // Cerrar la declaración
} else {
    mostrarError("ID de tarea no especificado.");
}
?>

<a href="index.php">Volver</a>
