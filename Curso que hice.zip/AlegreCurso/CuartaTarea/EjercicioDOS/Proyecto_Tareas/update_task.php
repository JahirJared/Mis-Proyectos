<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    $id = validarEntrada($_POST['id']);
    $titulo = validarEntrada($_POST['titulo']);
    $descripcion = validarEntrada($_POST['descripcion']);

    if (!empty($id) && !empty($titulo) && !empty($descripcion)) {
        $stmt = $conn->prepare("UPDATE tareas SET titulo=?, descripcion=? WHERE id=? AND usuario=?");
        $stmt->bind_param("ssis", $titulo, $descripcion, $id, $_SESSION['username']); // Vincular parámetros

        if ($stmt->execute()) {
            echo "Tarea actualizada con éxito.";
        } else {
            mostrarError($stmt->error); // Mostrar errores de ejecución
        }

        $stmt->close(); // Cerrar la declaración
    } else {
        mostrarError("Todos los campos son obligatorios."); // Validar campos obligatorios
    }
} elseif (isset($_GET['id'])) {
    $id = validarEntrada($_GET['id']);

    $stmt = $conn->prepare("SELECT * FROM tareas WHERE id=? AND usuario=?");
    $stmt->bind_param("is", $id, $_SESSION['username']); // Vincular parámetros
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $titulo = $row['titulo'];
        $descripcion = $row['descripcion'];
    } else {
        mostrarError("Tarea no encontrada.");
        exit();
    }

    $stmt->close(); // Cerrar la declaración
} else {
    mostrarError("ID de tarea no especificado.");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Actualizar Tarea</title>
</head>
<body>
    <h1>Actualizar Tarea</h1>
    <form method="post" action="update_task.php">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>">
        Título: <input type="text" name="titulo" value="<?php echo htmlspecialchars($titulo); ?>" required><br>
        Descripción: <textarea name="descripcion" required><?php echo htmlspecialchars($descripcion); ?></textarea><br>
        <input type="submit" value="Actualizar">
    </form>
    <a href="index.php">Volver</a>
</body>
</html>
