<?php
include 'config.php';
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = validarEntrada($_POST['usuario']);
    $password = validarEntrada($_POST['password']);

    // Corregir la consulta preparada
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE username=? AND password=?");
    $stmt->bind_param("ss", $usuario, $password);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "Login exitoso.";
    } else {
        echo "Usuario o contraseña incorrectos.";
    }

    $stmt->close();
}
?>
