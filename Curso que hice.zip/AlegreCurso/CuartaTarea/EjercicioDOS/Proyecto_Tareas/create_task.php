<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include 'config.php';
include 'functions.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $titulo = validarEntrada($_POST['titulo']);
    $descripcion = validarEntrada($_POST['descripcion']);

    if (!empty($titulo) && !empty($descripcion)) {
        $stmt = $conn->prepare("INSERT INTO tareas (titulo, descripcion, usuario) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $titulo, $descripcion, $_SESSION['username']); // Vincular parámetros

        if ($stmt->execute()) {
            echo "Tarea creada con éxito.";
        } else {
            mostrarError($stmt->error); // Mostrar errores de ejecución
        }

        $stmt->close(); // Cerrar la declaración
    } else {
        mostrarError("Todos los campos son obligatorios."); // Validar campos obligatorios
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Crear Tarea</title>
</head>
<body>
    <h1>Crear Tarea</h1>
    <form method="post" action="create_task.php">
        Título: <input type="text" name="titulo" required><br>
        Descripción: <textarea name="descripcion" required></textarea><br>
        <input type="submit" value="Crear">
    </form>
    <a href="index.php">Volver</a>
</body>
</html>
