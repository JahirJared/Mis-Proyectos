<?php
class MiClase {
    // Propiedades
    public $propiedad1;
    private $propiedad2;
        // Constructor
    public function __construct($prop1, $prop2) {
        $this->propiedad1 = $prop1;
        $this->propiedad2 = $prop2;
    }
        // Método
    public function metodoEjemplo() {
        return $this->propiedad1 . " " . $this->propiedad2;
    }
}
// Creación de un objeto de la clase MiClase
$miObjeto = new MiClase('valor1', 'valor2');
// Llamada al método metodoEjemplo y impresión del resultado
echo $miObjeto->metodoEjemplo(); // Salida: valor1 valor2
?>
