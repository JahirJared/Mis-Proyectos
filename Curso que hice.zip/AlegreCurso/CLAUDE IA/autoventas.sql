CREATE DATABASE autoventas;

USE autoventas;

CREATE TABLE autos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    anio INT NOT NULL,
    precio DECIMAL(10, 2) NOT NULL,
    imagen VARCHAR(255) NOT NULL
);

CREATE TABLE contactos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    mensaje TEXT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

select *from contactos;

-- Insertar algunos datos de ejemplo en la tabla autos
INSERT INTO autos (marca, modelo, anio, precio, imagen) VALUES
('Toyota', 'Corolla', 2022, 25000.00, 'img/toyota-corolla.jpg'),
('Honda', 'Civic', 2023, 27000.00, 'img/honda-civic.jpg'),
('Ford', 'Mustang', 2021, 45000.00, 'img/ford-mustang.jpg');