document.addEventListener('DOMContentLoaded', () => {
    cargarAutos();
    document.getElementById('formulario-contacto').addEventListener('submit', enviarFormulario);
});

async function cargarAutos() {
    try {
        const response = await fetch('obtener_autos.php');
        const autos = await response.json();
        const listaAutos = document.getElementById('lista-autos');
        
        autos.forEach(auto => {
            const autoElement = document.createElement('div');
            autoElement.className = 'auto';
            autoElement.innerHTML = `
                <img src="${auto.imagen}" alt="${auto.marca} ${auto.modelo}">
                <h3>${auto.marca} ${auto.modelo}</h3>
                <p>Año: ${auto.anio}</p>
                <p>Precio: $${auto.precio}</p>
            `;
            listaAutos.appendChild(autoElement);
        });
    } catch (error) {
        console.error('Error al cargar los autos:', error);
    }
}

async function enviarFormulario(e) {
    e.preventDefault();
    const nombre = document.getElementById('nombre').value;
    const email = document.getElementById('email').value;
    const mensaje = document.getElementById('mensaje').value;

    try {
        const response = await fetch('enviar_contacto.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nombre, email, mensaje }),
        });
        const result = await response.json();
        if (result.success) {
            alert('Mensaje enviado con éxito');
            document.getElementById('formulario-contacto').reset();
        } else {
            alert('Error al enviar el mensaje');
        }
    } catch (error) {
        console.error('Error al enviar el formulario:', error);
        alert('Error al enviar el mensaje');
    }
}