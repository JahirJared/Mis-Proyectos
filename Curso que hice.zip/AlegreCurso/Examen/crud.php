<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mibaseexamen";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


$sql = "INSERT INTO Usuarios (nombre, email) VALUES ('Juan', 'juan@example.com')";
if ($conn->query($sql) === TRUE) {
    echo "Nuevo registro creado con éxito<br>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error . "<br>";
}


$sql = "SELECT id, nombre, email FROM Usuarios";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Nombre: " . $row["nombre"]. " - Email: " . $row["email"]. "<br>";
    }
} else {
    echo "0 resultados<br>";
}


$sql = "UPDATE Usuarios SET email='nuevoemail@example.com' WHERE nombre='Juan'";
if ($conn->query($sql) === TRUE) {
    echo "Registro actualizado con éxito<br>";
} else {
    echo "Error actualizando el registro: " . $conn->error . "<br>";
}


$sql = "DELETE FROM Usuarios WHERE nombre='Juan'";
if ($conn->query($sql) === TRUE) {
    echo "Registro eliminado con éxito<br>";
} else {
    echo "Error eliminando el registro: " . $conn->error . "<br>";
}

$conn->close();
?>
