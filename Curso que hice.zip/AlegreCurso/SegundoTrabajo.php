<?php
// Clase base
class Animal {
    public $nombre;
 
    public function __construct($nombre) {
        $this->nombre = $nombre;
    }
 
    public function hacerSonido() {
        return "Sonido de animal";
    }
}
 
// Clase derivada (herencia)
class Perro extends Animal {
 
    public function hacerSonido() {
        return "Guau";
    }
}
 
// Otra clase derivada (herencia)
class Gato extends Animal {
 
    public function hacerSonido() {
        return "Miau";
    }
}
 
// Polimorfismo en acción
function hacerSonidoDeAnimal(Animal $animal) {
    echo $animal->nombre . " dice " . $animal->hacerSonido() . "<br>";
}
 
// Creación de objetos de las clases derivadas
$miPerro = new Perro("Firulais");
$miGato = new Gato("Misu");
 
// Llamadas polimórficas
hacerSonidoDeAnimal($miPerro); // Firulais dice Guau
hacerSonidoDeAnimal($miGato); // Misu dice Miau
?>


