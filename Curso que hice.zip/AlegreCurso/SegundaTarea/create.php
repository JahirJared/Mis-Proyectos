<?php

include 'config.php'; // Incluye el archivo de configuración de la base de datos

include 'functions.php'; // Incluye el archivo de funciones

?>

<!DOCTYPE html>

<html>

<head>

<title>Crear Usuario</title>

</head>

<body>

<h1>Crear Usuario</h1>

<form method="post">

Nombre: <input type="text" name="nombre" required><br>

Email: <input type="email" name="email" required><br>

Edad: <input type="number" name="edad" required><br>

<input type="submit" value="Crear">

</form>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") { // Verifica si el formulario fue enviado

$nombre = validarEntrada($_POST['nombre']); // Valida y asigna el valor del nombre

$email = validarEntrada($_POST['email']); // Valida y asigna el valor del email

$edad = validarEntrada($_POST['edad']); // Valida y asigna el valor de la edad

// Verificar si los datos no están vacíos

if (!empty($nombre) && !empty($email) && !empty($edad)) {// Prepara la consulta SQL

    $sql = "INSERT INTO usuarios (nombre, email, edad) VALUES ('$nombre', '$email', $edad)";
    
    if ($conn->query($sql) === TRUE) { // Ejecuta la consulta y verifica si se ejecutó correctamente
    
    echo "Nuevo registro creado con éxito"; // Mensaje de éxito
    
    } else {
    
    mostrarError($conn->error); // Muestra el error si la consulta falla
    
    }
    
    } else {
    
    mostrarError("Todos los campos son obligatorios"); // Muestra un error si hay campos vacíos
    
    }
    
    }
    
    ?>
    
    </body>
    
    </html>