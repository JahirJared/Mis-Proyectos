<?php

include 'config.php'; // Incluye el archivo de configuración de la base de datos

include 'functions.php'; // Incluye el archivo de funciones

?>

<!DOCTYPE html>

<html>

<head>

<title>Actualizar Usuario</title>

</head>

<body>

<h1>Actualizar Usuario</h1>

<form method="post">

ID: <input type="text" name="id" required><br>

Nombre: <input type="text" name="nombre" required><br>

Email: <input type="email" name="email" required><br>

Edad: <input type="number" name="edad" required><br>

<input type="submit" name="actualizar" value="Actualizar">

</form>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['actualizar'])) { // Verifica si el formulario fue enviado y el botón actualizar fue presionado

$id = validarEntrada($_POST['id']); // Valida y asigna el valor del ID

$nombre = validarEntrada($_POST['nombre']); // Valida y asigna el valor del nombre

$email = validarEntrada($_POST['email']); // Valida y asigna el valor del email

$edad = validarEntrada($_POST['edad']); // Valida y asigna el valor de la edad

// Verificar si los datos no están vacíos

if (!empty($id) && !empty($nombre) && !empty($email) && !empty($edad)) {

// Prepara la consulta SQL

$sql = "UPDATE usuarios SET nombre='$nombre', email='$email', edad=$edad WHERE id=$id";

if ($conn->query($sql) === TRUE) { // Ejecuta la consulta y verifica si se ejecutó correctamente

echo "Registro actualizado con éxito"; // Mensaje de éxito

} else {

mostrarError($conn->error); // Muestra el error si la consulta falla

}

} else {

mostrarError("Todos los campos son obligatorios"); // Muestra un error si hay campos vacíos

}

}

?>

</body>

</html>