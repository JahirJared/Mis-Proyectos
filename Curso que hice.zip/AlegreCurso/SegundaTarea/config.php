<?php

// Configuración de la base de datos

$servername = "localhost"; // Nombre del servidor

$username = "root"; // Nombre de usuario de la base de datos

$password = ""; // Contraseña de la base de datos

$dbname = "mi_base_de_datos"; // Nombre de la base de datos

// Crear conexión

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión

if ($conn->connect_error) {

die("Conexión fallida: " . $conn->connect_error); // Mostrar mensaje de error si la conexión falla

}

?>