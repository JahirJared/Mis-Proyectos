<?php

include 'config.php'; // Incluye el archivo de configuración de la base de datos

include 'functions.php'; // Incluye el archivo de funciones

?>

<!DOCTYPE html>

<html>

<head>

<title>Eliminar Usuario</title>

</head>

<body>

<h1>Eliminar Usuario</h1>

<form method="post">

ID: <input type="text" name="id" required><br>

<input type="submit" name="eliminar" value="Eliminar">

</form>

<?php

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['eliminar'])) { // Verifica si el formulario fue enviado y el botón eliminar fue presionado

$id = validarEntrada($_POST['id']); // Valida y asigna el valor del ID

// Verificar si el ID no está vacío

if (!empty($id)) {

// Prepara la consulta SQL

$sql = "DELETE FROM usuarios WHERE id=$id";

if ($conn->query($sql) === TRUE) { // Ejecuta la consulta y verifica si se ejecutó correctamente

echo "Registro eliminado con éxito"; // Mensaje de éxito

} else {

mostrarError($conn->error); // Muestra el error si la consulta falla

}

} else {

mostrarError("El campo ID es obligatorio"); // Muestra un error si el campo ID está vacío

}

}

?>

</body>

</html>