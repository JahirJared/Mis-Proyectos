<!DOCTYPE html>

<html>

<head>

<title>Gestión de Usuarios</title>

</head>

<body>

<h1>Gestión de Usuarios</h1>

<ul>

<li><a href="create.php">Crear Usuario</a></li>

<li><a href="read.php">Leer Usuarios</a></li>

<li><a href="update.php">Actualizar Usuario</a></li>

<li><a href="delete.php">Eliminar Usuario</a></li>

</ul>

</body>

</html>