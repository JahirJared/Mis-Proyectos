<?php

// Función para validar entradas

function validarEntrada($data) {

$data = trim($data); // Elimina espacios en blanco al principio y al final

$data = stripslashes($data); // Elimina barras invertidas

$data = htmlspecialchars($data); // Convierte caracteres especiales en entidades HTML

return $data; // Retorna la entrada validada

}

// Función para manejar errores

function mostrarError($mensaje) {

echo "<p style='color:red;'>Error: $mensaje</p>"; // Muestra el mensaje de error en rojo

}

?>