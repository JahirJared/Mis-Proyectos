<?php

include 'config.php'; // Incluye el archivo de configuración de la base de datos

include 'functions.php'; // Incluye el archivo de funciones

?>

<!DOCTYPE html>

<html>

<head>

<title>Leer Usuarios</title>

</head>

<body>

<h1>Leer Usuarios</h1>

<?php

// Consulta SQL para seleccionar todos los usuarios

$sql = "SELECT id, nombre, email, edad FROM usuarios";

$result = $conn->query($sql);

if ($result->num_rows > 0) { // Verifica si hay resultados

while($row = $result->fetch_assoc()) { // Itera sobre cada fila de resultados

echo "ID: " . $row["id"]. " - Nombre: " . $row["nombre"]. " - Email: " . $row["email"]. " - Edad: " . $row["edad"]. "<br>";

}

} else {

echo "0 resultados"; // Mensaje si no hay resultados

}

?>
</body>

</html>