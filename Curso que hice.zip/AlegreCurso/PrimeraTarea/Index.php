<?php
// Incluyendo el archivo que contiene la clase Persona
include 'Persona.php';

// Array para almacenar objetos Persona
$personas = [];

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $edad = $_POST['edad'];
    $genero = $_POST['genero'];
    $nuevaPersona = new Persona($nombre, $edad, $genero);
    $personas[] = $nuevaPersona;
}

// Añadir algunas personas por defecto para mostrar
$personas[] = new Persona("Jahir", 19, "Masculino");
$personas[] = new Persona("Ana", 19, "Femenino");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Personas</title>
</head>
<body>
    <?php
    // Mostrar la informacion de cada persona en el array
    foreach ($personas as $persona) {
        $persona->saludar();
        $persona->mostrarInformacion();
        echo "<br><br>"; // Salto entre las personas
    }

    echo "Al agregar una persona al formulario, la que ya este existente se Reiniciciara
    y se sustituira por la Nueva persona que se agregue al formulario.";
    echo "<br><br>";
    ?>

    <!-- Formulario para agregar una nueva persona -->
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="nombre">Nombre:</label><br>
        <input type="text" id="nombre" name="nombre" required><br>
        <label for="edad">Edad:</label><br>
        <input type="number" id="edad" name="edad" required><br>
        <label for="genero">Género:</label><br>
        <input type="text" id="genero" name="genero" required><br><br>
        <input type="submit" value="Agregar Persona">
    </form>
</body>
</html>
