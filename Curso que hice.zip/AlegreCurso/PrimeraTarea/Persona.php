<?php
// Defnicion de la clase Persona
class Persona {
    // Propiedades de la clase
    public $nombre;
    public $edad;
    public $genero;

    // Constructor de la clase para iniciar las propiedades
    public function __construct($nombre, $edad, $genero) {
        $this->nombre = $nombre;
        $this->edad = $edad;
        $this->genero = $genero;
    }

    // Meteodo para saludar
    public function saludar() {
        echo "Hola, mi nombre es " . $this->nombre . ".<br>";
    }

    // Metodo para mostrar la informacion completa de la persona
    public function mostrarInformacion() {
        echo "Nombre: " . $this->nombre . "<br>";
        echo "Edad: " . $this->edad . "<br>";
        echo "Género: " . $this->genero . "<br>";
    }
}
?>
