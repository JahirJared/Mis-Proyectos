CREATE DATABASE libreria_online;

USE libreria_online;

CREATE TABLE autores (

id INT AUTO_INCREMENT PRIMARY KEY,

nombre VARCHAR(255) NOT NULL

);

CREATE TABLE categorias (

id INT AUTO_INCREMENT PRIMARY KEY,

nombre VARCHAR(255) UNIQUE NOT NULL

);

CREATE TABLE usuarios (

id INT AUTO_INCREMENT PRIMARY KEY,

nombre VARCHAR(255) NOT NULL,

email VARCHAR(255) UNIQUE NOT NULL

);

CREATE TABLE libros (

id INT AUTO_INCREMENT PRIMARY KEY,

titulo VARCHAR(255) NOT NULL,

id_autor INT,

id_categoria INT,

precio DECIMAL(10, 2) NOT NULL CHECK (precio > 0),

stock INT,

FOREIGN KEY (id_autor) REFERENCES autores(id),

FOREIGN KEY (id_categoria) REFERENCES categorias(id)

);

CREATE TABLE pedidos (

id INT AUTO_INCREMENT PRIMARY KEY,

id_libro INT,

id_usuario INT,

cantidad INT,

fecha DATE,

FOREIGN KEY (id_libro) REFERENCES libros(id) ON DELETE CASCADE,

FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE RESTRICT

);

-- Asegúrate de que la tabla 'libros' y 'pedidos' existan y tengan las columnas necesarias
DESCRIBE libros;
DESCRIBE pedidos;

DELIMITER //
CREATE TRIGGER actualizar_stock 
AFTER INSERT ON pedidos
FOR EACH ROW
BEGIN
  UPDATE libros
  SET stock = stock - NEW.cantidad 
  WHERE id = NEW.id_libro;
END;
//
DELIMITER ;


CREATE INDEX idx_titulo_libro ON libros(titulo);

CREATE INDEX idx_nombre_autor ON autores(nombre);

-- Insertar registros en la tabla 'autores'
INSERT INTO autores (nombre) VALUES 
('Gabriel García Márquez'),
('Isabel Allende'),
('J.K. Rowling');

-- Insertar registros en la tabla 'categorias'
INSERT INTO categorias (nombre) VALUES 
('Novela'),
('Fantasía'),
('Ciencia Ficción');

-- Insertar registros en la tabla 'usuarios'
INSERT INTO usuarios (nombre, email) VALUES 
('Juan Pérez', 'juan.perez@example.com'),
('Maria López', 'maria.lopez@example.com'),
('Carlos García', 'carlos.garcia@example.com');

-- Insertar registros en la tabla 'libros'
INSERT INTO libros (titulo, id_autor, id_categoria, precio, stock) VALUES
('Cien años de soledad', 1, 1, 19.99, 100),
('La casa de los espíritus', 2, 1, 14.99, 150),
('Harry Potter y la piedra filosofal', 3, 2, 9.99, 200),
('El amor en los tiempos del cólera', 1, 1, 15.99, 120),
('Harry Potter y la cámara secreta', 3, 2, 9.99, 180);

