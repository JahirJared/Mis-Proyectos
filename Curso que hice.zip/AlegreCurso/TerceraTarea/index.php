<?php include 'config.php'; ?>

<!DOCTYPE html>

<html>

<head>

<title>Librería Online</title>

</head>

<body>

<h1>Bienvenido a la Librería Online</h1>

<a href="libros.php">Gestión de Libros</a><br>

<a href="pedidos.php">Gestión de Pedidos</a>

</body>

</html>