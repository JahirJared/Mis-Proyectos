<?php

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

$id_libro = $_POST['id_libro'];

$id_usuario = $_POST['id_usuario'];

$cantidad = $_POST['cantidad'];

$fecha = date('Y-m-d');

$sql = "INSERT INTO pedidos (id_libro, id_usuario, cantidad, fecha) VALUES ($id_libro, $id_usuario, $cantidad, '$fecha')";

if ($conn->query($sql) === TRUE) {

echo "Pedido realizado correctamente.";

} else {

echo "Error: " . $sql . "<br>" . $conn->error;

}

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Gestión de Pedidos</title>

</head>

<body>

<h1>Gestión de Pedidos</h1>

<form method="post" action="pedidos.php">

Libro: <select name="id_libro" required>

<?php

$result = $conn->query("SELECT id, titulo FROM libros");

while ($row = $result->fetch_assoc()) {

echo "<option value='" . $row['id'] . "'>" . $row['titulo'] . "</option>";

}

?>

</select><br>

Usuario: <select name="id_usuario" required>

<?php

$result = $conn->query("SELECT id, nombre FROM usuarios");

while ($row = $result->fetch_assoc()) {

echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";

}

?>

</select><br>

Cantidad: <input type="number" name="cantidad" required><br>

<input type="submit" value="Realizar Pedido">

</form>

</body>

</html>