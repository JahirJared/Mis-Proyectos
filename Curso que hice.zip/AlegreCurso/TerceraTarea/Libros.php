<?php

include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

$titulo = $_POST['titulo'];

$id_autor = $_POST['id_autor'];

$id_categoria = $_POST['id_categoria'];

$precio = $_POST['precio'];

$stock = $_POST['stock'];

$sql = "INSERT INTO libros (titulo, id_autor, id_categoria, precio, stock) VALUES ('$titulo', $id_autor, $id_categoria, $precio, $stock)";

if ($conn->query($sql) === TRUE) {

echo "Nuevo libro agregado correctamente.";

} else {

echo "Error: " . $sql . "<br>" . $conn->error;

}

}

?>

<!DOCTYPE html>

<html>

<head>

<title>Gestión de Libros</title>

</head>

<body>

<h1>Gestión de Libros</h1>

<form method="post" action="libros.php">

Título: <input type="text" name="titulo" required><br>

Autor: <select name="id_autor" required>

<?php

$result = $conn->query("SELECT id, nombre FROM autores");

while ($row = $result->fetch_assoc()) {

echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";

}

?>

</select><br>

Categoría: <select name="id_categoria" required>

<?php

$result = $conn->query("SELECT id, nombre FROM categorias");

while ($row = $result->fetch_assoc()) {

echo "<option value='" . $row['id'] . "'>" . $row['nombre'] . "</option>";

}

?>

</select><br>

Precio: <input type="number" name="precio" step="0.01" required><br>

Stock: <input type="number" name="stock" required><br>

<input type="submit" value="Agregar Libro">

</form>

</body>

</html>